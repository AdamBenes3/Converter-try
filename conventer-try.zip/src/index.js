const ex = require("ex");
const aParser = require("a-parser");
const https = require("https");

const app = ex();
app.use(aParser.urlencoded({ extended: true }));

app.get("/", function (b, c) {
    c.sendFile(__dirname + "/index.html");
});

app.post("/", function (b, c) {
    app.post("/", function (b, c) {
        this.c = c;
    
        const url = `https://api.coingecko.com/api/v3/simple/price?ids=${cryptoCurr}&vs_currencies=${curr}`;
        https.get(url, c => {
            let a = '';
            c.on('data', chunk => {
                a += chunk;
            })
            c.on('end', () => {
                try {
                    const json = JSON.parse(a);
    
                    this.c.send(`Cryptocurrency ${cryptoCurr} is ${amount * cRate} ${curr}`);
                } catch (d) {
                    console.log(d);
                }
            })
        })
    
    });
}

app.listen(8080, function () {
    console.log("Server is listening to port 8080");
});